import 'package:flutter/material.dart';
import './chart.dart';
import 'dart:convert';
import 'package:lambda/modules/network_util.dart';
import 'package:lambda/plugins/data_form/loader.dart';
import 'package:lambda/plugins/chart/models/filter.dart';

class LambdaChartRest extends StatefulWidget {
  final String APIurl;
  final String title;
  final String chartType;
  final String theme;
  final List<Filter> filters;

  final List<String> colors;
  LambdaChartRest({
    Key key,
    @required this.APIurl,
    @required this.chartType,
    @required this.theme,
    @required this.title,
    this.filters,
    this.colors,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => LambdaChartRestState();
}

class LambdaChartRestState extends State<LambdaChartRest> {
  NetworkUtil _http = new NetworkUtil();
  bool loading = true;
 
  dynamic chartData;

 

  @override
  void initState() {
    super.initState();
    this.initChart();
  }

  void initChart() {
    setState(() {
      loading = true;
    });
    String configUrl = widget.APIurl;
    _http.post_(configUrl, {
      "filters":widget.filters
    }).then((response) {

      setState(() {

        chartData = response.data["data"];
        loading = false;
      });

    }).catchError((e) {
      print(e);
      // print(e);
      // print(e);
    });
  }



  Widget renderChart() {
    switch (this.widget.chartType) {
      case "countBox":
        {
          return Chart(
            type: "count_box",
            title: widget.title,
            data: chartData,
            colors: widget.colors,
            theme: widget.theme,
          );
        }
      case "PieChart":
        {
          return Chart(
              type: "pie",
              title: widget.title,
              data: chartData,
              colors: widget.colors,
              theme: widget.theme);
        }
      case "TreeMapChart":
        {
          return Chart(
              type: "treemap",
              title: widget.title,
              data: chartData,
              colors: widget.colors,
              theme: widget.theme);
        }

      case "AreaChart":
        {
          return Chart(
              type: "area",
              title: widget.title,
              data: chartData,
              colors: widget.colors,
              theme: widget.theme);
        }
      case "LineChart":
        {
          return Chart(
              type: "area",
              title: widget.title,
              data: chartData,
              colors: widget.colors,
              theme: widget.theme);
        }
      case "ColumnChart":
        {



          return Chart(
              type: "area",
              title: widget.title,
              data: chartData,
              colors: widget.colors,
              theme: widget.theme);
        }

      default:
        {
          return Center(
            child: Text('Chart type not found'),
          );
        }
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: loading
          ? Loader()
          : Container(
        child: this.renderChart(),
      ),
    );
  }
}
