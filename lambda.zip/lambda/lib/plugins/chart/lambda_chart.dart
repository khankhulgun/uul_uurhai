import 'package:flutter/material.dart';
import './chart.dart';
import 'dart:convert';
import 'package:lambda/modules/network_util.dart';
import 'package:lambda/plugins/data_form/loader.dart';
import 'package:lambda/plugins/chart/models/filter.dart';

class LambdaChart extends StatefulWidget {
  final String schemaID;
  final String theme;
  final bool hideTitle;
  final List<Filter> filters;

  LambdaChart({
    Key key,
    @required this.schemaID,
    @required this.theme,
    this.filters,
    this.hideTitle =false,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => LambdaChartState();
}

class LambdaChartState extends State<LambdaChart> {
  NetworkUtil _http = new NetworkUtil();
  bool loading = true;
  String title = "";
  String type = "";
  Map<String, dynamic> counbox_data = new Map<String, dynamic>();
  Map<String, dynamic> pie_data = new Map<String, dynamic>();
  Map<String, dynamic> area_data = new Map<String, dynamic>();

  List<String> colors = [];

  @override
  void initState() {
    super.initState();
    this.initChart();
  }

  void initChart() {
    setState(() {
      loading = true;
    });
    String configUrl = '/lambda/puzzle/schema-public/chart/${widget.schemaID}';
    _http.get_(configUrl).then((response) {

      var schema_ = json.decode(response.data["data"]["schema"]);


      setState(() {
        title = response.data["data"]["name"];

        type = schema_["type"];

        if (schema_["type"] == "countBox") {
          counbox_data["color"] = schema_['bgColor'];
          counbox_data["icon"] = "newspaper";
          this.getCounBoxData(schema_);
        }

        if (schema_["type"] == "PieChart" ||
            schema_["type"] == "TreeMapChart") {
          this.getPieData(schema_);
        }
        if (schema_["type"] == "AreaChart" ||
            schema_["type"] == "ColumnChart" ||
            schema_["type"] == "LineChart") {
          this.getAreaData(schema_);
        }
      });
    }).catchError((e) {});
  }

  getCounBoxData(Map<String, dynamic> schema_) async {
    try {
      var response = await _http
          .post_('/ve/get-data-count', {"countFields": schema_["countFields"]});
      setState(() {
        counbox_data["count"] = response.data;
        loading = false;
      });
    } catch (RuntimeBinderException) {}
  }

  getPieData(Map<String, dynamic> schema_) async {
    try {
      var response = await _http.post_('/ve/get-data-pie', {
        "value": schema_["value"],
        "title": schema_["title"],
        "filters":widget.filters
      });


      String value_field = schema_["value"][0]["name"];
      String title_field = schema_["title"][0]["name"];

      List<Map<String, dynamic>> data = [];

      var titles = response.data.map((i) {
        return i[title_field];
      }).toList();

      for (Map i in response.data) {
        Map<String, dynamic> data_i = new Map();
        data_i['value'] = i[value_field];
        data_i['name'] = i[title_field];
        data.add(data_i);
      }

      setState(() {
        pie_data["data"] = data;
        pie_data["legend"] = titles;
        loading = false;
      });
    } catch (RuntimeBinderException) {
      print("EEEEEEE");
    }
  }

  getAreaData(Map<String, dynamic> schema_) async {
    try {
      var response = await _http.post_('/ve/get-data', {
        "axis": schema_["axis"],
        "lines": schema_["lines"],
        "filters":widget.filters
      });

      List<String> colorsData = [];
      for(dynamic line in schema_["lines"]){
        if(line["color"] != null && line["color"] != ""){
          colorsData.add(line["color"]);
        }
      }


      List<dynamic> axis = [];
      List<Map<String, dynamic>> series = [];

      for (Map axis_el in schema_["axis"]) {
        for (Map axisdata in response.data) {
          axis.add(axisdata[axis_el["name"]]);
        }
      }

      for (Map line in schema_["lines"]) {
        List<String> seriesData = [];
        for (Map line_data in response.data) {
          seriesData.add("${line_data[line["name"]]}");
        }

        Map<String, dynamic> area_data_pre = new Map<String, dynamic>();

        area_data_pre["name"] = line["title"];

        area_data_pre["smooth"] = true;

        area_data_pre["data"] = seriesData;

        if (type == "AreaChart") {
          area_data_pre["type"] = 'line';
          area_data_pre["areaStyle"] = {};
        }

        if (type == "LineChart") {
          area_data_pre["type"] = 'line';
        }

        if (type == "ColumnChart") {
          area_data_pre["type"] = 'bar';
        }

        series.add(area_data_pre);
      }


      setState(() {
        area_data["xdata"] = axis;
        area_data["data"] = series;
        colors  = colorsData;
        loading = false;
      });
    } catch (RuntimeBinderException) {
      print("ERROR");
    }
  }

  Widget renderChart() {
    switch (this.type) {
      case "countBox":
        {
          return Chart(
            type: "count_box",
            title: this.title,
            hideTitle: this.widget.hideTitle,
            data: counbox_data,
            theme: widget.theme,
          );
        }
      case "PieChart":
        {
          return Chart(
              type: "pie",
              title: this.title,
              hideTitle: this.widget.hideTitle,
              data: pie_data,
              colors: colors,
              theme: widget.theme);
        }
      case "TreeMapChart":
        {
          return Chart(
              type: "treemap",
              title: this.title,
              hideTitle: this.widget.hideTitle,
              colors: colors,
              data: pie_data,
              theme: widget.theme);
        }

      case "AreaChart":
        {
          return Chart(
              type: "area",
              title: this.title,
              hideTitle: this.widget.hideTitle,
              data: area_data,
              colors: colors,
              theme: widget.theme);
        }
      case "LineChart":
        {
          return Chart(
              type: "area",
              title: this.title,
              hideTitle: this.widget.hideTitle,
              data: area_data,
              colors: colors,
              theme: widget.theme);
        }
      case "ColumnChart":
        {


          return Chart(
              type: "area",
              title: this.title,
              hideTitle: this.widget.hideTitle,
              data: area_data,
              colors: colors,
              theme: widget.theme);
        }

      default:
        {
          return Center(
            child: Text('Chart type not found'),
          );
        }
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: loading
          ? Loader()
          : Container(
              child: this.renderChart(),
            ),
    );
  }
}
