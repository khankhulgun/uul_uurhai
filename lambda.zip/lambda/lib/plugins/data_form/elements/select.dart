import 'package:flutter/material.dart';
import 'package:searchable_dropdown/searchable_dropdown.dart';
import 'element_option.dart';
import '../utils/number.dart';

class SelectWidget extends StatefulWidget {
  final ElementOption option;

  SelectWidget({Key key, this.option}) : super(key: key);

  @override
  _SelectWidgetState createState() => _SelectWidgetState();
}

class _SelectWidgetState extends State<SelectWidget> {
  String relationKey = "";

  @override
  void initState() {
    super.initState();
    setRelationKey();
  }

  setRelationKey() {
    setState(() {

      relationKey = widget.option.component;

      if(widget.option.relations != null){

        if (widget.option.relations[widget.option.component] == null) {
          relationKey = widget.option.meta["relation"]["table"];
        }
      }

    });
  }

  void onChange(String value) {
    setState(() {
      if (isNumeric(value)) {
        var numberValue = int.parse(value);
        widget.option.onChange(widget.option.component, numberValue);
      } else {
        widget.option.onChange(widget.option.component, value);
      }
    });
  }

  List<dynamic> getOptions() {
    if (widget.option.meta["options"] != null &&
        widget.option.meta["options"].length >= 1) {
      return filterOption(widget.option.meta["options"]);
    } else {
      if(widget.option.relations != null){
        return filterOption(widget.option.relations[relationKey]);
      } return [];

    }
  }

  List<dynamic> filterOption(List<dynamic> _options) {
    if (_options != null) {
      if (widget.option.meta["relation"]["parentFieldOfForm"] != null) {
        if (widget.option
                .form[widget.option.meta["relation"]["parentFieldOfForm"]] !=
            null) {
          return _options
              .where((i) =>
                  i["parent_value"] ==
                  widget.option.form[widget.option.meta["relation"]
                      ["parentFieldOfForm"]])
              .toList();
        } else {
          return _options.length >= 1 ? _options : [];
        }
      } else {
        return _options.length >= 1 ? _options : [];
      }
    }
    return [];
  }

  String getDefaultValue(List<dynamic> options) {
    if (widget.option.form[widget.option.component] == null ||
        widget.option.form[widget.option.component] == "" ||
        widget.option.form[widget.option.component] == 0) {
      if(options.length >= 1){
        return options[0]["value"].toString();
      }
    } else {
      int selectedIndex = options.indexWhere((note) =>
          note["value"].toString() ==
          widget.option.form[widget.option.component].toString());

      if (selectedIndex >= 0) {
        return widget.option.form[widget.option.component].toString();
      } else {
        return options[0]["value"].toString();
      }
    }
  }

  Widget build(BuildContext context) {
    var options = getOptions();
    var defaultValue = getDefaultValue(options);

    return new Container(
        margin: new EdgeInsets.only(top: 5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new Text(widget.option.label,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
            new FormField(
              initialValue: defaultValue,
              validator: (_) {
                for (int i = 0; i < widget.option.rules.length; i++) {
                  if (widget.option.rules[i](
                      widget.option.form[widget.option.component]) !=
                      null)
                    return widget.option
                        .rules[i](widget.option.form[widget.option.component]);
                }
                return null;
              },
              builder: (FormFieldState<dynamic> field) {
                return InputDecorator(
                  decoration: InputDecoration().copyWith(
                    border: InputBorder.none,
                    errorText: field.errorText,

                  ),
                  child: SearchableDropdown.single(
                    items: options.map<DropdownMenuItem<String>>((dynamic data) {
                      return DropdownMenuItem<String>(
                        value: data['value'].toString(),
                        child: new Text(
                          data['label'].toString(),
                          style: new TextStyle(color: Colors.black),
                        ),
                      );
                    }).toList(),

                    closeButton:"Хаах",
                    value: defaultValue,
                    hint: widget.option.label,
                    searchHint: widget.option.label,
                    onChanged: onChange,
                    isExpanded: true,
                  ),
                );
              },
            ),

          ],
        ));
  }
}
