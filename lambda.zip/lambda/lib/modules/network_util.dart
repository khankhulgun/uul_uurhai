import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart' as secure;
import 'responseModel.dart';

import 'package:dio_http_cache/dio_http_cache.dart';

BaseOptions options = new BaseOptions(
  headers: {
//    'Authorization': 'Bearer ' + prefs.getString("TOKEN"),
    "X-Requested-With": "XMLHttpRequest",
    "Accept": "application/json",
    "Content-Type": "application/x-www-form-urlencoded"
  },
  connectTimeout: 100000,
  receiveTimeout: 100000,
);

ResponseModel r = ResponseModel.fromError();

class NetworkUtil {
  static NetworkUtil _instance = new NetworkUtil.internal();

  NetworkUtil.internal();

  final storage = new secure.FlutterSecureStorage();

  factory NetworkUtil() => _instance;
  Dio dio = new Dio(options);
  Response response;

  initNetwork(baseUrl) {
    options.baseUrl = baseUrl;

    dio.interceptors.add(DioCacheManager(CacheConfig(baseUrl: baseUrl)).interceptor);
  }

  Future<dynamic> get(String url, {dynamic params, String base}) async {
    if (base != null) {
      options.baseUrl = base;
    }

    try {
//      dio.interceptors.add(
//        InterceptorsWrapper(onRequest: (Options options) async {
//          String jwt = await storage.read(key: 'jwt');
//          options.headers["token"] = jwt;
//          return options;
//        }),
//      );

      response = await dio.get(url, queryParameters: params ?? null,   options: buildCacheOptions(Duration(days: 7), forceRefresh: true),);
//      print(response);
    } on DioError catch (e) {
      if (e.response != null) {
//        print(e.response.data);
//        print(e.response.headers);
//        print(e.response.request);
      } else {
//        print(e.request);
//        print(e.message);
      }
    }
    return response;
  }
  Future<dynamic> post(String url, body, {String base}) async {
    print(body);
    if (base != null) {
      options.baseUrl = base;
    }

    try {
//      dio.interceptors.add(
//        InterceptorsWrapper(onRequest: (Options options) async {
//          String jwt = await storage.read(key: 'jwt');
//          options.headers["token"] = jwt;
//          return options;
//        }),
//      );
      response = await dio.post(url, data: body);
      print(response);
      if (response.statusCode == 200) {
        r = ResponseModel.fromJson(response.data);
      }
    } on DioError catch (e) {
      r = ResponseModel.fromError();
      if (e.response != null) {
        print(e.response.data);
        print(e.response.headers);
        print(e.response.request);
      } else {
        print(e.request);
        print(e.message);
      }
    }
    return r;
  }

  Future<dynamic> get_(String url, {String base}) async {

    if (base != null) {
      options.baseUrl = base;
    }
    try {
      dio.interceptors.add(
        InterceptorsWrapper(onRequest: (Options options) async {
          String jwt = await storage.read(key: "jwt");
          if(jwt != null && jwt != ""){
            options.headers["Cookie"] = 'token=${jwt}';
            options.headers["Authorization"] = 'Bearer ${jwt}';
          }
          return options;
        }),
      );

      response = await dio.get(url, options: buildCacheOptions(Duration(days: 7), forceRefresh: true),);
//      print(response);
    } on DioError catch (e) {
      if (e.response != null) {
        throw (e.response.data);
      } else {
        print(e.request);
        print(e.type);
        throw (e.message);
      }
    }
    return response;
  }
  Future<dynamic> post_(String url, body, {String base, bool cache:true}) async {

    if (base != null) {
      options.baseUrl = base;
    }

    try {
      dio.interceptors.add(
        InterceptorsWrapper(onRequest: (Options options) async {
          String jwt = await storage.read(key: "jwt");
       //   print(jwt);
          if(jwt != null && jwt != ""){
            options.headers["Cookie"] = 'token=${jwt}';
            options.headers["Authorization"] = 'Bearer ${jwt}';
          }
          return options;
        }),
      );
      if(cache)
        response = await dio.post(url, data: body, options: buildCacheOptions(Duration(days: 7), forceRefresh: true));
      else
        response = await dio.post(url, data: body, options: buildCacheOptions(Duration(days: 0), forceRefresh: true));


    } on DioError catch (e) {


      if (e.response != null) {

        throw (e.response.data);
      } else {

        throw (e.message);
      }
    }
    return response;
  }




}
