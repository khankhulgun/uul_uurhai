class KrudModel {
  dynamic model = null;

  KrudModel(dynamic model) {}

  Future<List<dynamic>> krudList(url) {}

  Future<void> krudSingle() {}
}
