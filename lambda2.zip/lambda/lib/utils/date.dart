import 'package:intl/intl.dart';
String getDate(DateTime date){
  // DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm:ss");
  var formatter = new DateFormat('yyyy-MM-dd');

  // DateTime dateTime  = dateFormat.parse(date);

  return formatter.format(date);
}
String getDateTime(DateTime date){
//  DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm:ss");
  var formatter = new DateFormat('yyyy-MM-dd HH:mm');

 // DateTime dateTime  = dateFormat.parse(date);

  return formatter.format(date);
}
String getTime(DateTime date){
 // DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm:ss");
  var formatter = new DateFormat('HH:mm');

//  DateTime dateTime  = dateFormat.parse(date);

  return formatter.format(date);
}