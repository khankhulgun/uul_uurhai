class KrudAbstract {}
