import 'package:flutter/material.dart';
import 'element_option.dart';
import 'package:intl/intl.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:date_format/date_format.dart';

class DateTimePickerWidget extends StatefulWidget {
  final ElementOption option;

  final bool dateTimeMode;

  DateTimePickerWidget({Key key, this.option, this.dateTimeMode = false}) : super(key: key);

  @override
  _DateTimePickerWidgetState createState() => _DateTimePickerWidgetState();
}

class _DateTimePickerWidgetState extends State<DateTimePickerWidget> {


  @override
  void initState() {
    super.initState();
  }
  void onChange(DateTime value){
    if(value != null){
      setState(() {
        if(widget.dateTimeMode){
          widget.option.onChange(widget.option.component, formatDate(value, [yyyy, '-', mm, '-', dd , " ", HH,":",nn,":",ss]));
        } else {
          widget.option.onChange(widget.option.component, formatDate(value, [yyyy, '-', mm, '-', dd]));
        }
      });
    } else {
      widget.option.onChange(widget.option.component, null);
    }

  }

  Widget build(BuildContext context) {
    return new Container(
        margin: new EdgeInsets.only(top: 5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            new Text(widget.option.label, style: new TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
            new DateTimeField(
              format: widget.dateTimeMode ?  DateFormat("yyyy-MM-dd HH:mm:ss") :DateFormat("yyyy-MM-dd"),
              onShowPicker: widget.dateTimeMode ? (context, currentValue) async {
                final date = await showDatePicker(
                    context: context,
                    firstDate: DateTime(1900),
                    initialDate: currentValue ?? DateTime.now(),
                    lastDate: DateTime(2100));
                if (date != null) {
                  final time = await showTimePicker(
                    context: context,
                    initialTime:
                    TimeOfDay.fromDateTime(currentValue ?? DateTime.now()),
                  );
                  return DateTimeField.combine(date, time);
                } else {
                  return currentValue;
                }
              } :(context, currentValue) {
                return showDatePicker(
                    context: context,
                    firstDate: DateTime(1900),
                    initialDate: currentValue ?? DateTime.now(),
                    lastDate: DateTime(2100));
              },
              initialValue: widget.option.form[widget.option.component] != null ? DateTime.parse(widget.option.form[widget.option.component]) : null,
              decoration: widget.option.decoration ??
                  widget.option.decoration ??
                  new InputDecoration(
                    hintText: widget.option.label ?? "",
                    helperText: "",
                  ),
              onChanged: onChange,
              validator: (_) {

                for (int i = 0; i < widget.option.rules.length; i++) {
                  if (widget.option.rules[i](widget.option.form[widget.option.component]) != null)
                    return widget.option.rules[i](widget.option.form[widget.option.component]);
                }
                return null;
              },
            ),
          ],
        )
    );

  }
}
