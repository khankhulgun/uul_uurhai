import 'package:flutter/material.dart';
import 'checkbox.dart';
import 'element_option.dart';
import 'input.dart';
import 'select.dart';
import 'radio.dart';
import 'dateTime.dart';
import 'checkbox.dart';
import 'image.dart';
import 'subForm/subForm.dart';
import '../rule.dart';


Widget element({String type ="", String key = "", Map<String, dynamic> form, Map<String, dynamic> meta, String label = "", InputDecoration decoration, void Function(String component , dynamic value) onChange, List<FormFieldValidator> rules,dynamic relations}) {

  switch(type) {
    case "SubForm": {
      return new SubformWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
          )
      );
    }
    break;
    case "Text": {
      return new InputWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
          )
      );
    }
    break;
    case "Textarea": {
      return new InputWidget(
        maxLines: 4,
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
          )
      );
    }
    break;
    case "CK": {
      return new InputWidget(
        maxLines: 4,
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
          )
      );
    }
    break;
    case "Number": {
      return new InputWidget(
          keyboardType:TextInputType.number,
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
          )
      );
    }
    break;
    case "Password": {
      return new InputWidget(
          obscureText:true,
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
          )
      );
    }
    break;
    case "Email": {
      var emailValidation = getRule("email");
      return new InputWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:[...rules, emailValidation],
          )
      );
    }
    break;
    case "Select": {
      return new SelectWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
            relations:relations,
          )
      );
    }
    break;
    case "ISelect": {
      return new SelectWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,
            relations:relations,
          )
      );
    }
    break;
    case "Radio": {
      return new RadioWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,

          )
      );
    }
    break;
    case "Checkbox": {
      return new CheckboxWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,

          )
      );
    }
    break;
    case "Date": {
      return new DateTimePickerWidget(
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,

          )
      );
    }
    break;
    case "DateTime": {
      return new DateTimePickerWidget(
          dateTimeMode:true,
          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,

          )
      );
    }
    break;
    case "Image": {
      return new ImageUploadWidget(

          option: ElementOption(
            component:key,
            label:label,
            form:form,
            meta:meta,
            decoration:decoration,
            onChange:onChange,
            rules:rules,

          )
      );
    }
    break;
    default: {
     return Container();
    }
    break;
  }
}